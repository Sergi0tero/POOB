package Dominio;

public class Recta extends Figura{

    public Recta(int[][] tablero, boolean bolflag, int posy){
        super('R');
        this.tablero = tablero;
        this.bolflag = bolflag;
        this.posy = posy;
        setTablero();
    }

    int[][] estado1 = new int[][]{
            {1,1,1,1},
            {0,0,0,0},
            {0,0,0,0},
            {0,0,0,0}
    };

    int[][] estado2 = new int[][]{
            {1,0,0,0},
            {1,0,0,0},
            {1,0,0,0},
            {1,0,0,0}
    };

    protected int estados = 2;
    protected int[][] currentstate = estado1;
    protected int currentflag = 1;

    private void setTablero(){
        if(currentflag == 1){
            currentstate = estado1;
        }else if(currentflag ==2){
            currentstate = estado2;
        }
        for(int i=0; i< estado1.length; i++){
            for(int j=0; j< estado1.length; j++){
                tablero[i][j+4] = currentstate[i][j];
            }
        }
    }


    @Override
    public int[][] nextState(){
        boolean flag = true;
            for(int i=0; i<20; i++){
                for(int j=0; j<10; j++){
                    if(tablero[i][j] == 1 && currentflag == 1 && flag){
                        currentflag =2;
                        currentstate = estado2;
                        tablero[i][j] = 0;
                        tablero[i][j+2] = 0;
                        tablero[i][j+3] = 0;
                        tablero[i+1][j+1] = 1;
                        tablero[i+2][j+1] = 1;
                        tablero[i+3][j+1] = 1;
                        flag = false;

                    }else if (tablero[i][j] ==1 && currentflag == 2 && flag && j != 0 && j < 8){
                        currentflag = 1;
                        currentstate = estado1;
                        tablero[i+1][j] = 0;
                        tablero[i+2][j] = 0;
                        tablero[i+3][j] = 0;
                        tablero[i][j-1] = 1;
                        tablero[i][j+1] = 1;
                        tablero[i][j+2] = 1;
                        flag = false;
                    }
                }
            }
            return tablero;
    }

    @Override
    protected int[][] getEstado() {
        return currentstate;
    }

    public boolean getflag(){
        return bolflag;
    }

    @Override
    public int[][] abajo() {
        boolean bandera = true;
        for (int i = 19; i >= 0; i -= 1) {
            for (int j = 9; j >= 0; j -= 1) {
                if (tablero[19][j] == 1 && bandera) {
                    bandera = false;
                    llegoAbajo();
                }
                if (currentflag == 1 && j >= 3 && bandera) {
                    if (tablero[i][j] == 1 && (tablero[i + 1][j] == -1 || tablero[i + 1][j - 1] == -1 || tablero[i + 1][j - 2] == -1 || tablero[i + 1][j - 3] == -1)) {
                        bandera = false;
                        llegoAbajo();
                    } else if (tablero[i][j] == 1 && i < 19) {
                        bandera = false;
                        tablero[i][j] = 0;
                        tablero[i][j - 1] = 0;
                        tablero[i][j - 2] = 0;
                        tablero[i][j - 3] = 0;
                        tablero[i + 1][j] = 1;
                        tablero[i + 1][j - 1] = 1;
                        tablero[i + 1][j - 2] = 1;
                        tablero[i + 1][j - 3] = 1;
                    }
                }else if (currentflag == 2 && bandera) {
                    if (tablero[i][j] == 1 && (tablero[i + 1][j] == -1)) {
                        bandera = false;
                        llegoAbajo();
                    } else if (tablero[i][j] == 1 && i < 19 && i > 2) {
                        bandera = false;
                        tablero[i - 3][j] = 0;
                        tablero[i + 1][j] = 1;
                    }
                    }
                }
            }

        return tablero;
    }

    @Override
    public int[][] mueveDerecha() {
        boolean bandera = true;
        for(int i = 19; i>=0; i-=1) {
            for (int j = 9; j >= 0; j -= 1) {
                if (currentflag == 1 && j > 2 && j < 9  && tablero[i][j] == 1 && tablero[i][j - 3] == 1  && tablero[i][j+1] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j - 3] = 0;
                    tablero[i][j + 1] = 1;
                } else if (currentflag == 2 && i > 2 && j < 9 && tablero[i][j] == 1 && tablero[i - 3][j] == 1 && tablero[i][j+1] == 0 && tablero[i-1][j+1] == 0 && tablero[i-2][j+1] == 0 && tablero[i-3][j+1] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j] = 0;
                    tablero[i - 2][j] = 0;
                    tablero[i - 3][j] = 0;
                    tablero[i][j + 1] = 1;
                    tablero[i - 1][j + 1] = 1;
                    tablero[i - 2][j + 1] = 1;
                    tablero[i - 3][j + 1] = 1;
                }
            }
        }
        return tablero;
    }

    @Override
    public int[][] mueveIzquierda() {
        boolean bandera = true;
        for(int i = 19; i>=0; i-=1) {
            for (int j = 9; j >= 0; j -= 1) {
                if (currentflag == 1 && j > 3  && tablero[i][j] == 1 && tablero[i][j - 3] == 1  && tablero[i][j - 4] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i][j - 4] = 1;
                } else if (currentflag == 2 && j > 0 && i > 2 && tablero[i][j] == 1 && tablero[i - 3][j] == 1 && tablero[i][j-1] == 0 && tablero[i-1][j-1] == 0 && tablero[i-2][j-1] == 0 && tablero[i-3][j-1] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j] = 0;
                    tablero[i - 2][j] = 0;
                    tablero[i - 3][j] = 0;
                    tablero[i][j - 1] = 1;
                    tablero[i - 1][j - 1] = 1;
                    tablero[i - 2][j - 1] = 1;
                    tablero[i - 3][j - 1] = 1;
                }
            }
        }
        return tablero;
    }

    @Override
    public void setposy(int posy){
        this.posy = posy;
    }
}
