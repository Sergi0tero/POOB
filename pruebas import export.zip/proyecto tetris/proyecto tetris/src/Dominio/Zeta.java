package Dominio;

import java.util.ArrayList;

public class Zeta extends Figura{

    public Zeta(int[][] tablero, boolean bolflag, int posy){
        super('Z');
        this.tablero = tablero;
        this.bolflag = bolflag;
        this.posy = posy;
        setTablero();
    }

    int[][] estado1 = new int[][]{
            {3,3,0},
            {0,3,3},
            {0,0,0}
    };

    int[][] estado2 = new int[][]{
            {0,3,0},
            {3,3,0},
            {3,0,0}
    };

    protected int estados = 2;
    protected int[][] currentstate = estado1;
    protected int currentflag = 1;

    private void setTablero(){
        if(currentflag == 1){
            currentstate = estado1;
        }else if(currentflag ==2){
            currentstate = estado2;
        }
        for(int i=0; i< estado1.length; i++){
            for(int j=0; j< estado1.length; j++){
                tablero[i][j+4] = currentstate[i][j];
            }
        }
    }

    @Override
    protected int[][] getEstado() {
        return currentstate;
    }

    public boolean getflag(){
        return bolflag;
    }

    @Override
    public int[][] abajo() {
        boolean bandera = true;
            for (int i = 19; i >= 0; i -= 1) {
                for (int j = 9; j >= 0; j -= 1) {
                    if (tablero[19][j] == 3 && bandera) {
                        bandera = false;
                        llegoAbajo();
                    }
                    if (currentflag == 1 && bandera) {
                        if (tablero[i][j] == 3 && (tablero[i + 1][j - 1] == -1 || tablero[i + 1][j] == -1 || tablero[i][j - 2] == -1)) {
                            bandera = false;
                            llegoAbajo();
                        } else if (tablero[i][j] == 3 && i < 19) {
                            bandera = false;
                            tablero[i][j] = 0;
                            tablero[i - 1][j - 1] = 0;
                            tablero[i - 1][j - 2] = 0;
                            tablero[i + 1][j] = 3;
                            tablero[i + 1][j - 1] = 3;
                            tablero[i][j - 2] = 3;
                        }
                    }
                    if (currentflag == 2 && bandera) {
                        if (tablero[i][j] == 3 && (tablero[i][j + 1] == -1 || tablero[i + 1][j] == -1)) {
                            bandera = false;
                            llegoAbajo();
                        } else if (tablero[i][j] == 3 && i < 19) {
                            bandera = false;
                            tablero[i - 1][j] = 0;
                            tablero[i - 2][j + 1] = 0;
                            tablero[i + 1][j] = 3;
                            tablero[i][j + 1] = 3;

                        }
                    }
                }
            }
        return tablero;
    }

    @Override
    public int[][] mueveDerecha() {
        boolean bandera = true;
        for(int i = 19; i>=0; i-=1) {
            for (int j = 9; j >= 0; j -= 1) {
                if (currentflag == 1 && i > 0 && j > 1 && j < 9 && tablero[i][j] == 3 && tablero[i - 1][j-2] == 3 && tablero[i][j + 1] == 0 && tablero[i - 1][j] == 0 && bandera) {
                        bandera = false;
                        tablero[i][j - 1] = 0;
                        tablero[i - 1][j - 2] = 0;
                        tablero[i][j + 1] = 3;
                        tablero[i - 1][j] = 3;
                } else if(currentflag == 2 && j < 8 && i > 2 && tablero[i][j] == 3 && tablero[i - 2][j+1] == 3 && tablero[i][j + 1] == 0 && tablero[i - 1][j + 2] == 0 && tablero[i - 2][j + 2] == 0 && bandera) {
                        bandera = false;
                        tablero[i][j] = 0;
                        tablero[i - 1][j] = 0;
                        tablero[i - 2][j + 1] = 0;
                        tablero[i][j + 1] = 3;
                        tablero[i - 1][j + 2] = 3;
                        tablero[i - 2][j + 2] = 3;
                }
            }
        }
        return tablero;
    }

    @Override
    public int[][] mueveIzquierda() {
        boolean bandera = true;
        for(int i = 19; i>=0; i-=1) {
            for (int j = 9; j >= 0; j -= 1) {
                if (currentflag == 1 && i > 0 && j > 2 && tablero[i][j] == 3 && tablero[i - 1][j-2] == 3 && tablero[i][j - 2] == 0 && tablero[i - 1][j - 3] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j - 1] = 0;
                    tablero[i][j - 2] = 3;
                    tablero[i - 1][j - 3] = 3;
                } else if(currentflag == 2 && i > 2 && j < 8 && tablero[i][j] == 3 && tablero[i - 2][j+1] == 3 && tablero[i][j - 1] == 0 && tablero[i - 1][j - 1] == 0 && tablero[i - 2][j] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j + 1] = 0;
                    tablero[i - 2][j + 1] = 0;
                    tablero[i][j - 1] = 3;
                    tablero[i - 1][j - 1] = 3;
                    tablero[i - 2][j] = 3;
                }
            }
        }
        return tablero;
    }

    @Override
    public int[][] nextState(){
        boolean flag = true;
        for(int i=0; i<20; i++){
            for(int j=0; j<10; j++){
                if(tablero[i][j] == 3 && currentflag == 1 && flag){
                    currentflag =2;
                    currentstate = estado2;
                    tablero[i][j] = 0;
                    tablero[i+1][j+2] = 0;
                    tablero[i+1][j] = 3;
                    tablero[i+2][j] = 3;
                    flag = false;

                }else if (tablero[i][j] == 3 && currentflag == 2 && flag && j < 9){
                    currentflag = 1;
                    currentstate = estado1;
                    tablero[i+1][j-1] = 0;
                    tablero[i+2][j-1] = 0;
                    tablero[i][j-1] = 3;
                    tablero[i+1][j+1] = 3;
                    flag = false;
                }
            }
        }
        return tablero;
    }

    @Override
    public void setposy(int posy){
        this.posy = posy;
    }

}
