package Dominio;

import java.util.Arrays;

public abstract class Figura {


    protected int[][] tablero;
    protected boolean bolflag;
    protected int posy = 1;
    protected char type;
    protected int[][] f;
    protected boolean flag =true;

    public Figura(char type){
        this.type = type;
    }


    protected abstract int[][] getEstado();


    public abstract int[][] abajo();
    public abstract int[][] nextState();
    public abstract int[][] mueveDerecha();
    public abstract  boolean getflag();
    public abstract  void setposy(int posy);
    public abstract int[][] mueveIzquierda();


    protected void llegoAbajo(){
        for (int i =19; i>=0; i-=1) {
            for (int j = 9; j>=0; j-=1) {
                if(tablero[i][j] != 0){
                    tablero[i][j] = -1;
                }
            }
        }
        bolflag = false;
    }


    protected void imprime(){
        for(int n=0; n< 20; n++){
            System.out.println(Arrays.toString(tablero[n]));
        }
        System.out.println("");
    }
}
