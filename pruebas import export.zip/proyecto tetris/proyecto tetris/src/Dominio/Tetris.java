package Dominio;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;


public class Tetris {

    private final int heigth = 20;
    private final int width = 10;

    private int[][] tablero = new int[heigth][width];
    private final char[] figuras = {'R','L','Z','T','C' };
    protected boolean bolflag = true;
    protected int posy = 1;
    public Figura figura;

    public  Tetris(){
        for(int i=0; i<heigth; i++){
            for(int j=0; j<width; j++){
                tablero[i][j] = 0;
            }
        }
    }

    public Tetris(int[][] tablero){
        this.tablero = tablero;
    }

    public void nuevafigura() {
        int flag = (int) (Math.random() * 5);
        char tipo = figuras[flag];
//        char tipo = 'C';
        // switchcase
        if (tipo == 'C') {
            figura = new Cuadro(tablero, bolflag, posy);
        }
        else if (tipo == 'T') {
            figura = new Te(tablero, bolflag, posy);
        }
        else if (tipo == 'Z') {
            figura = new Zeta(tablero, bolflag, posy);
        }
        else if (tipo == 'L') {
            figura = new Ele(tablero, bolflag, posy);
        }
        else if (tipo == 'R') {
            figura = new Recta(tablero, bolflag, posy);
        }
    }

    public boolean terminoficha(){
        return figura.getflag();
    }

    public  void setflag(boolean flag){this.bolflag = flag;}

    public boolean terminojuego(){
        boolean bandera = false;
        for(int k=0; k < 9; k++){
            if(tablero[2][k] == -1){
                bandera = true;
            }
        }
        return bandera;
    }

    public int[][] getTablero() {
        return tablero;
    }
}
