package Dominio;

import java.util.ArrayList;

public class Te extends Figura{

    public Te(int[][] tablero, boolean bolflag, int posy){
        super('T');
        this.tablero = tablero;
        this.bolflag = bolflag;
        this.posy = posy;
        setTablero();
    }



    int[][] estado1 = new int[][]{
            {4,4,4},
            {0,4,0},
            {0,0,0}
    };

    int[][] estado2 = new int[][]{
            {0,0,4},
            {0,4,4},
            {0,0,4}
    };

    int[][] estado3 = new int[][]{
            {0,0,0},
            {0,4,0},
            {4,4,4}
    };

    int[][] estado4 = new int[][]{
            {4,0,0},
            {4,4,0},
            {4,0,0}
    };

    protected int estados = 4;
    protected int[][] currentstate = estado1 ;
    protected int currentflag = 1;

    private void setTablero(){
        if(currentflag == 1){
            currentstate = estado1;
        }else if(currentflag ==2){
            currentstate = estado2;
        }else if(currentflag ==3){
            currentstate = estado3;
        }else if(currentflag ==4){
            currentstate = estado4;
        }
        for(int i=0; i< estado1.length; i++){
            for(int j=0; j< estado1.length; j++){
                tablero[i][j+4] = currentstate[i][j];
            }
        }
    }

    @Override
    protected int[][] getEstado() {
        return currentstate;
    }

    public boolean getflag(){
        return bolflag;
    }

    @Override
    public int[][] abajo() {
        boolean bandera = true;
            for (int i = 19; i >= 0; i -= 1) {
                for (int j = 9; j >= 0; j -= 1) {
                    if (tablero[19][j] == 4 && bandera) {
                        llegoAbajo();
                        bandera = false;
                    }
                    else if (j >= 1 && j <= 8 && currentflag == 1 && bandera) {
                        if (tablero[i][j] == 4 && (tablero[i][j - 1] == -1 || tablero[i][j + 1] == -1 || tablero[i + 1][j] == -1)) {
                            llegoAbajo();
                            bandera = false;
                        } else if (tablero[i][j] == 4 && tablero[i-1][j] == 4 && i < 19 && tablero[i + 1][j] == 0 && bandera) {
                            bandera = false;
                            tablero[i - 1][j] = 0;
                            tablero[i - 1][j - 1] = 0;
                            tablero[i - 1][j + 1] = 0;
                            tablero[i][j - 1] = 4;
                            tablero[i][j + 1] = 4;
                            tablero[i + 1][j] = 4;
                        }
                    }
                    else if (j >= 1 && currentflag == 2 && bandera) {
                        if (tablero[i][j] == 4 && (tablero[i][j - 1] == -1 || tablero[i + 1][j] == -1)) {
                            llegoAbajo();
                            bandera = false;
                        } else if (tablero[i][j] == 4 && tablero[i-1][j] == 4 && i < 19 && tablero[i + 1][j] == 0 && bandera) {
                            bandera = false;
                            tablero[i - 2][j] = 0;
                            tablero[i - 1][j - 1] = 0;
                            tablero[i + 1][j] = 4;
                            tablero[i][j - 1] = 4;
                        }
                    }
                    else if (j >= 2 && currentflag == 3 && bandera) {
                        if (tablero[i][j] == 4 && (tablero[i + 1][j] == -1 || tablero[i + 1][j - 1] == -1 || tablero[i + 1][j - 2] == -1)) {
                            llegoAbajo();
                            bandera = false;
                        } else if (tablero[i][j] == 4 && tablero[i-1][j-1] == 4 && i < 19 && tablero[i + 1][j] == 0 && bandera) {
                            bandera = false;
                            tablero[i][j] = 0;
                            tablero[i - 1][j - 1] = 0;
                            tablero[i][j - 2] = 0;
                            tablero[i + 1][j] = 4;
                            tablero[i + 1][j - 1] = 4;
                            tablero[i + 1][j - 2] = 4;
                        }
                    }
                    else if (currentflag == 4 && bandera) {
                        if (tablero[i][j] == 4 && (tablero[i][j + 1] == -1 || tablero[i + 1][j] == -1)) {
                            llegoAbajo();
                            bandera = false;
                        } else if (tablero[i][j] == 4 && tablero[i-1][j] == 4 && i < 19 && tablero[i + 1][j] == 0 && bandera ) {
                            bandera = false;
                            tablero[i - 2][j] = 0;
                            tablero[i - 1][j + 1] = 0;
                            tablero[i][j + 1] = 4;
                            tablero[i + 1][j] = 4;
                        }
                    }
                }
            }
        return tablero;
    }

    @Override
    public int[][] mueveDerecha() {
        boolean bandera = true;
            for (int i = 19; i >= 0; i -= 1) {
                for (int j = 9; j >= 0; j -= 1) {
                    if (currentflag == 1 && j < 8 && i > 0 && tablero[i - 1][j + 1] == 4 && tablero[i][j] == 4  && tablero[i - 1][j + 2] == 0 && tablero[i][j + 1] == 0 && bandera) {
                        bandera = false;
                        tablero[i][j] = 0;
                        tablero[i - 1][j - 1] = 0;
                        tablero[i][j + 1] = 4;
                        tablero[i - 1][j + 2] = 4;
                    } else if (currentflag ==  2 && j > 0 && j < 9 && i > 1 && tablero[i][j] == 4 && tablero[i - 1][j - 1] == 4 && tablero[i][j+1] == 0 && tablero[i - 1][j+1] == 0 && tablero[i - 2][j+1] == 0) {
                        bandera = false;
                        tablero[i][j] = 0;
                        tablero[i - 1][j - 1] = 0;
                        tablero[i - 2][j] = 0;
                        tablero[i][j + 1] = 4;
                        tablero[i - 1][j + 1] = 4;
                        tablero[i - 2][j + 1] = 4;
                    } else if (currentflag == 3 && j < 9 && i > 0 && tablero[i][j] == 4 && tablero[i - 1][j - 1] == 4 && tablero[i][j + 1] == 0 && tablero[i - 1][j] == 0) {
                        bandera = false;
                        tablero[i][j - 2] = 0;
                        tablero[i - 1][j - 1] = 0;
                        tablero[i - 1][j] = 4;
                        tablero[i][j + 1] = 4;
                    } else if (currentflag == 4 && j < 8 && i > 1 && tablero[i][j] == 4 && tablero[i - 1][j + 1] == 4 && tablero[i][j+1] == 0 && tablero[i-1][j+2] == 0 && tablero[i-2][j+1] == 0) {
                        bandera = false;
                        tablero[i][j] = 0;
                        tablero[i - 1][j] = 0;
                        tablero[i - 2][j] = 0;
                        tablero[i][j + 1] = 4;
                        tablero[i - 1][j + 2] = 4;
                        tablero[i - 2][j + 1] = 4;
                    }
                }
            }
        return tablero;
    }

    @Override
    public int[][] mueveIzquierda() {
        boolean bandera = true;
        for (int i = 19; i >= 0; i -= 1) {
            for (int j = 9; j >= 0; j -= 1) {
                if (currentflag == 1 && j > 1 && j < 9 && i > 0 && tablero[i - 1][j + 1] == 4 && tablero[i][j] == 4  && tablero[i][j - 1] == 0 && tablero[i - 1][j - 2] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j + 1] = 0;
                    tablero[i][j - 1] = 4;
                    tablero[i - 1][j - 2] = 4;
                } else if (currentflag ==  2 && j > 1 && i > 1 && tablero[i][j] == 4 && tablero[i - 1][j - 1] == 4 && tablero[i][j - 1] == 0 && tablero[i - 1][j - 2] == 0 && tablero[i - 2][j - 1] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j] = 0;
                    tablero[i - 2][j] = 0;
                    tablero[i][j - 1] = 4;
                    tablero[i - 1][j - 2] = 4;
                    tablero[i - 2][j - 1] = 4;
                } else if (currentflag == 3 && j > 2 && i > 0 && tablero[i][j] == 4 && tablero[i - 1][j - 1] == 4 && tablero[i][j - 3] == 0 && tablero[i - 1][j - 2] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j - 1] = 0;
                    tablero[i][j - 3] = 4;
                    tablero[i - 1][j - 2] = 4;
                } else if (currentflag == 4 && j > 0 && i > 1 && tablero[i][j] == 4 && tablero[i - 1][j + 1] == 4 && tablero[i][j-1] == 0 && tablero[i-1][j-1] == 0 && tablero[i-2][j-1] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j + 1] = 0;
                    tablero[i - 2][j] = 0;
                    tablero[i][j - 1] = 4;
                    tablero[i - 1][j - 1] = 4;
                    tablero[i - 2][j - 1] = 4;
                }
            }
        }
        return tablero;
    }

    @Override
    public int[][] nextState(){
        boolean flag = true;
        for(int i=0; i<20; i++){
            for(int j=0; j<10; j++){
                if(tablero[i][j] == 4 && currentflag == 1 && flag){
                    currentflag =2;
                    currentstate = estado2;
                    tablero[i][j] = 0;
                    tablero[i][j+2] = 0;
                    tablero[i+1][j] = 4;
                    tablero[i+2][j+1] = 4;
                    flag = false;

                }else if (tablero[i][j] == 4 && currentflag == 2 && flag && j < 9){
                    currentflag = 3;
                    currentstate = estado3;
                    tablero[i+2][j] = 0;
                    tablero[i][j+1] =0;
                    tablero[i+1][j+1] = 4;
                    flag = false;

                }else if (tablero[i][j] == 4 && currentflag == 3 && flag){
                    currentflag = 4;
                    currentstate = estado4;
                    tablero[i+1][j-1] = 0;
                    tablero[i+2][j] = 4;
                    flag = false;

                }else if (tablero[i][j] == 4 && currentflag == 4 && flag && j > 0){
                    currentflag = 1;
                    currentstate = estado1;
                    tablero[i+1][j+1] = 0;
                    tablero[i+2][j] = 0;
                    tablero[i][j+1] = 4;
                    tablero[i][j-1] = 4;
                    flag = false;
                }
            }
        }
        return tablero;
    }

    @Override
    public void setposy(int posy){
        this.posy = posy;
    }


}
