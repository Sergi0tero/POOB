package Dominio;

import java.util.Arrays;

public class Cuadro extends  Figura{

    protected int estados = 1;

    public Cuadro(int[][] tablero, boolean bolflag, int posy ){
        super('C');
        this.tablero = tablero;
        this.bolflag = bolflag;
        this.posy = posy;
        setTablero();
    }

    int[][] estado1 = new int[][]{
            {5,5},
            {5,5}
    };

    private void setTablero(){
        for(int i=0; i< estado1.length; i++){
            for(int j=0; j< estado1.length; j++){
                    tablero[i][j+4] = estado1[i][j];
            }
        }
    }


    @Override
    protected int[][] getEstado() {return tablero;}

    public boolean getflag(){
        return bolflag;
    }


    @Override
    public int[][] abajo() {
        boolean bandera = true;
            for (int i = 19; i >= 0; i -= 1) {
                for (int j = 9; j >= 0; j -= 1) {
                    if (tablero[19][j] == 5 && bandera) {
                        bandera = false;
                        llegoAbajo();
                    } else if (j > 0 && tablero[i][j] == 5 && (tablero[i + 1][j] == -1 || tablero[i + 1][j - 1] == -1) && bandera) {
                        bandera = false;
                        llegoAbajo();
                    } else if (tablero[i][j] == 5 && i < 19 && bandera) {
                        bandera = false;
                        tablero[i - 1][j] = 0;
                        tablero[i - 1][j-1] = 0;
                        tablero[i + 1][j] = 5;
                        tablero[i + 1][j-1] = 5;
                    }

                }
            }
        return tablero;
    }

    @Override
    public int[][] nextState() {
        return tablero;
    }

    @Override
    public int[][] mueveDerecha() {
        boolean bandera = true;
        for (int i = 19; i >= 0; i -= 1) {
            for (int j = 9; j >= 0; j -= 1) {
                if (j > 0 && j < 9 && i > 0 && tablero[i][j] == 5 && tablero[i - 1][j] == 5 && tablero[i][j - 1] == 5 && tablero[i][j + 1] == 0 && tablero[i - 1][j + 1] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j - 1] = 0;
                    tablero[i - 1][j - 1] = 0;
                    tablero[i][j + 1] = 5;
                    tablero[i - 1][j + 1] = 5;
                }
            }
        }
        return tablero;
    }

    @Override
    public int[][] mueveIzquierda() {
        boolean bandera = true;
        for (int i = 19; i >= 0; i -= 1) {
            for (int j = 9; j >= 0; j -= 1) {
                if (j > 1 && i > 0 && tablero[i][j] == 5 && tablero[i - 1][j] == 5 && tablero[i][j - 1] == 5 && tablero[i][j - 2] == 0 && tablero[i - 1][j - 2] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j] = 0;
                    tablero[i][j - 2] = 5;
                    tablero[i - 1][j -2] = 5;
                }
            }
        }
        return tablero;
    }

    @Override
    public void setposy(int posy){
        this.posy = posy;
    }

}
