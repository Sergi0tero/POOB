package Dominio;

import java.util.ArrayList;

public class Ele extends Figura{

    public Ele(int[][] tablero, boolean bolflag, int posy){
        super('L');
        this.tablero = tablero;
        this.bolflag = bolflag;
        this.posy = posy;
        setTablero();
    }

    int[][] estado1 = new int[][]{
            {2,0,0},
            {2,0,0},
            {2,2,0}
    };

    int[][] estado2 = new int[][]{
            {0,0,2},
            {2,2,2},
            {0,0,0}
    };

    int[][] estado3 = new int[][]{
            {2,2,0},
            {0,2,0},
            {0,2,0}
    };

    int[][] estado4 = new int[][]{
            {2,2,2},
            {2,0,0},
            {0,0,0}
    };

    protected int estados = 4;
    protected int[][] currentstate = estado1;
    protected int currentflag = 1;

    private void setTablero(){
        for(int i=0; i< estado1.length; i++){
            for(int j=0; j< estado1.length; j++){
                tablero[i][j+4] = currentstate[i][j];
            }
        }
    }

    @Override
    protected int[][] getEstado() {
        return currentstate;
    }

    public boolean getflag(){
        return bolflag;
    }

    @Override
    public int[][] abajo() {
        boolean bandera = true;
        for(int i = 19; i>=0; i-=1) {
            for (int j = 9; j >= 0; j -= 1) {
                if(tablero[19][j] == 2 && bandera){
                    bandera =false;
                    llegoAbajo();
                }
                if(currentflag == 1 && j >= 1 && bandera) {
                    if (tablero[i][j] == 2 && (tablero[i + 1][j - 1] == -1 || tablero[i + 1][j] == -1)) {
                        bandera =false;
                        llegoAbajo();
                    }else if (tablero[i][j] == 2 && i < 19) {
                        bandera = false;
                        tablero[i - 2][j - 1] = 0;
                        tablero[i][j] = 0;
                        tablero[i + 1][j] = 2;
                        tablero[i + 1][j - 1] = 2;
                    }
                }else if(currentflag == 2 && j >= 2 && bandera) {
                    if (tablero[i][j] == 2 && (tablero[i + 1][j - 2] == -1 || tablero[i + 1][j - 1] == -1 || tablero[i + 1][j] == -1)) {
                        bandera =false;
                        llegoAbajo();
                    } else if (tablero[i][j] == 2 && i < 19) {
                        bandera =false;
                        tablero[i-1][j] =0;
                        tablero[i][j-1] =0;
                        tablero[i][j-2] =0;
                        tablero[i+1][j] = 2;
                        tablero[i+1][j-1] = 2;
                        tablero[i+1][j-2] = 2;
                    }
                } else if(currentflag == 3 && j >= 1 && bandera) {
                    if (tablero[i][j] == 2 && (tablero[i - 1][j - 1] == -1 || tablero[i + 1][j] == -1)) {
                        bandera =false;
                        llegoAbajo();
                    } else if (tablero[i][j] == 2 && tablero[i-1][j] == 2 && i < 19 && tablero[i + 1][j] == 0) {
                        bandera =false;
                        tablero[i-2][j-1] =0;
                        tablero[i-2][j] =0;
                        tablero[i-1][j-1] =2;
                        tablero[i+1][j] =2;
                    }
                } else if(currentflag == 4 && bandera) {
                    if (tablero[i][j] == 2 && (tablero[i][j + 2] == -1 || tablero[i][j + 1] == -1 || tablero[i + 1][j] == -1)) {
                        bandera =false;
                        llegoAbajo();
                    } else if (tablero[i][j] == 2 && i <19) {
                        bandera =false;
                        tablero[i-1][j] =0;
                        tablero[i-1][j+1] =0;
                        tablero[i-1][j+2] =0;
                        tablero[i+1][j]=2;
                        tablero[i][j+1]=2;
                        tablero[i][j+2]=2;
                    }
                }
            }
        }
        return tablero;
    }

    @Override
    public int[][] nextState(){
        boolean flag = true;
        for(int i=0; i<20; i++){
            for(int j=0; j<10; j++){
                if(tablero[i][j] == 2 && currentflag == 1 && flag && j < 8){
                    currentflag =2;
                    currentstate = estado2;
                    tablero[i][j] = 0;
                    tablero[i+1][j] = 0;
                    tablero[i+1][j+2] = 2;
                    tablero[i+2][j+2] = 2;
                    flag = false;

                }else if (tablero[i][j] == 2 && currentflag == 2 && flag && j > 0){
                    currentflag = 3;
                    currentstate = estado3;
                    tablero[i+1][j-1] = 0;
                    tablero[i+1][j-2] = 0;
                    tablero[i][j-1] = 2;
                    tablero[i+2][j] = 2;
                    flag = false;

                }else if (tablero[i][j] == 2 && currentflag == 3 && flag && j > 0){
                    currentflag = 4;
                    currentstate = estado4;
                    tablero[i+1][j+1] = 0;
                    tablero[i+2][j+1] = 0;
                    tablero[i][j-1] = 2;
                    tablero[i+1][j-1] = 2;
                    flag = false;

                }else if (tablero[i][j] == 2 && currentflag == 4 && flag && j < 9){
                    currentflag = 1;
                    currentstate = estado1;
                    tablero[i][j+1] = 0;
                    tablero[i][j+2] = 0;
                    tablero[i+2][j] = 2;
                    tablero[i+2][j+1] = 2;
                    flag = false;
                }
            }
        }
        return tablero;
    }

    @Override
    public int[][] mueveDerecha() {
        boolean bandera =  true ;
        for(int i = 19; i>=0; i-=1) {
            for (int j = 9; j >= 0; j -= 1) {
                if (currentflag == 1 && i > 1 && j > 0 && j < 9 && tablero[i][j - 1] == 2 && tablero[i][j] == 2 && tablero[i][j+1] == 0 && tablero[i - 1][j] == 0 && tablero[i - 2][j] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j - 1] = 0;
                    tablero[i - 1][j - 1] = 0;
                    tablero[i - 2][j - 1] = 0;
                    tablero[i - 1][j] = 2;
                    tablero[i - 2][j] = 2;
                    tablero[i][j + 1] = 2;
                } else if (currentflag == 2 && i > 0 && j > 1 && j < 9 && tablero[i][j] == 2 && tablero[i - 1][j] == 2 && tablero[i][j+1] == 0 && tablero[i - 1][j + 1] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j - 2] = 0;
                    tablero[i - 1][j] = 0;
                    tablero[i][j + 1] = 2;
                    tablero[i - 1][j + 1] = 2;
                } else if (currentflag == 3 && i > 1 && j > 0 && j < 9 && tablero[i][j] == 2 && tablero[i - 2][j - 1] == 2 && tablero[i][j+1] == 0 && tablero[i - 1][j + 1] == 0 && tablero[i - 2][j + 1] == 0 && bandera){
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j] = 0;
                    tablero[i - 2][j - 1] = 0;
                    tablero[i][j + 1] = 2;
                    tablero[i - 1][j + 1] = 2;
                    tablero[i - 2][j + 1] = 2;
                } else if (currentflag == 4 && i > 0 && j < 7 && tablero[i][j] == 2 && tablero[i-1][j] == 2 && tablero[i][j + 1] == 0 && tablero[i - 1][j + 3] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j] = 0;
                    tablero[i][j + 1] = 2;
                    tablero[i - 1][j + 3] = 2;
                }
            }
        }
        return tablero;
    }

    public int[][] mueveIzquierda() {
        boolean bandera =  true ;
        for(int i = 19; i>=0; i-=1) {
            for (int j = 9; j >= 0; j -= 1) {
                if (currentflag == 1 && i > 1 && j > 1 && tablero[i][j - 1] == 2 && tablero[i][j] == 2 && tablero[i][j - 2] == 0 && tablero[i - 1][j - 2] == 0 && tablero[i - 2][j - 2] == 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j - 1] = 0;
                    tablero[i - 2][j - 1] = 0;
                    tablero[i][j - 2] = 2;
                    tablero[i - 1][j - 2] = 2;
                    tablero[i - 2][j - 2] = 2;
                } else if (currentflag == 2 && i > 0 && j > 2 && tablero[i][j] == 2 && tablero[i - 1][j] == 2 && tablero[i][j - 3] == 0 && tablero[i - 1][j - 1] == 0 && bandera) {
                    bandera =false;
                    tablero[i][j] = 0;
                    tablero[i-1][j] = 0;
                    tablero[i][j-3] = 2;
                    tablero[i-1][j-1] = 2;
                } else if (currentflag == 3 && i > 1 && j > 1 && tablero[i][j] == 2 && tablero[i - 2][j - 1] == 2 && tablero[i][j - 1] == 0 && tablero[i - 1][j - 1] == 0 && tablero[i - 2][j - 2] == 0 && bandera){
                    bandera =false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j] = 0;
                    tablero[i -2][j] = 0;
                    tablero[i][j - 1] = 2;
                    tablero[i-1][j - 1] = 2;
                    tablero[i-2][j - 2] = 2;
                } else if (currentflag == 4 && i > 0 && j > 0 && tablero[i][j] == 2 && tablero[i-1][j] == 2 && tablero[i][j - 1] == 0 && tablero[i - 1][j - 1] == 0 && bandera) {
                    bandera =false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j+2] = 0;
                    tablero[i][j -1] = 2;
                    tablero[i-1][j-1] = 2;
                }
            }
        }
        return tablero;
    }

    @Override
    public void setposy(int posy){
        this.posy = posy;
    }
}
