package Dominio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.Objects;

/**
 * Class Tablero
 *
 * @author  Archila-Otero
 */
public class Tablero {

    private Tablero tableroJuego;

    private boolean juega = true;
    private boolean pausa = true;

    private Timer timer;

    //JLabel
    private JLabel puntuacionLabel;
    private int puntuacion;

    //JPanel
    private JPanel[][] board;

    private String movimiento;

    //Color
    private Color colorInterno = Color.BLACK;
    private Color colorBorde = Color.BLUE;

    private int[][] tablero;
    private int boardHeight;
    private int boardWidth;

    private JPanel botonesTablero;

    private Tetris logictetris = new Tetris();

    /*
    Constructor del tablero
     */
    public Tablero(){
        tablero = logictetris.getTablero();
    }

    /*
    Crea el tableror del juego
    @param boardHeight Int que representa la cantidad de JPanels que hay de alto en el tablero(sumando el borde del mismo)
    @param boardWidth Int que representa la cantidad de JPanels que hay de ancho en el tablero(sumando el borde del mismo)
    @param width Int que representa el ancho del JFrame en el que se pondra el tablero
    @param height Int que representa el alto del JFrame en el que se pondra el tablero
     */
    public JPanel createGame(int boardHeight , int boardWidth, int widht, int height) {
        this.boardHeight = boardHeight;
        this.boardWidth = boardWidth;
        boardHeight += 2;
        boardWidth += 2;
        botonesTablero = new JPanel();
        botonesTablero.setLayout(new GridLayout(boardHeight, boardWidth,0, 0));
        board = new JPanel[boardHeight][boardWidth];
        for (int i = 0; i < boardHeight; i++) {
            for (int j = 0; j < boardWidth; j++) {
                JPanel boton = new JPanel();
                if (i == 0 || i == boardHeight - 1 || j == 0 || j == boardWidth - 1) {
                    boton.setBackground(colorBorde);
                }
                else{
                    boton.setBackground(colorInterno);
                }
                board[i][j] = boton;
                botonesTablero.add(boton);
            }
        }
        botonesTablero.setBounds((widht/2)-widht/6, 40, widht/3,((height*3)/4));
        botonesTablero.setOpaque(false);
        return botonesTablero;
    }

    /*
    Funcion que cambia el color del fondo (borde) del tablero
    @param newColor Color que representa el color que va a poner de fondo
     */
    public void changeColorBackGround(Color newColor){
        for (JPanel[] linea : board) {
            for(JPanel boton : linea) {
                if (boton.getBackground() == colorBorde) {
                    boton.setBackground(newColor);
                }
            }
        }
        this.colorBorde = newColor;
    }

    /*
    Devuelve el color del fondo(borde) del tablero
     */
    public Color getColorFondo(){
        return colorBorde;
    }

    public void changeColors(){
        verifiqueLinea();
        for(int i=0; i<20; i++){
            for(int j=0; j<10; j++){
                board[i + 1][j + 1].revalidate();
                if(tablero[i][j] == 1){
                    board[i + 1][j + 1].setBackground(Color.CYAN);
                } else if(tablero[i][j] == 2){
                    board[i + 1][j + 1].setBackground(Color.ORANGE);
                } else if(tablero[i][j] == 3){
                    board[i + 1][j + 1].setBackground(Color.GREEN);
                } else if(tablero[i][j] == 4){
                    board[i + 1][j + 1].setBackground(Color.MAGENTA);
                }else if(tablero[i][j] == 5){
                    board[i + 1][j + 1].setBackground(Color.yellow);
                }else if(tablero[i][j] == 0){
                    board[i + 1][j + 1].setBackground(Color.black);
                }
            }
        }
    }

    private void verifiqueLinea(){
        for(int i=19; i>=0; i-=1) {
            int contador = 0;
            for (int j = 9; j >= 0; j-=1) {
                if (tablero[i][j] == -1) contador += 1;
                if (contador == 10){
                    puntuacion += 200;
                    puntuacionLabel.setText("Puntuacion: " + puntuacion);
                    bajelineas(i, j);
                }
            }
        }
    }

    private void bajelineas(int k, int l){
        for(int i = k; i>0; i-=1){
            for(int j = l; j>=0; j-=1){
                for (int m = 0; m < 10; m++) {
                    tablero[i][m] = tablero[i - 1][m];
                }
            }
        }
    }

    public void setPuntuacion(JLabel puntuacionLabel){
        this.puntuacionLabel = puntuacionLabel;
    }

    public void inicie(){
        logictetris.nuevafigura();
        timer = new Timer(700, this::juegue);
        timer.start();
        juega = logictetris.terminojuego();
        changeColors();
    }

    public Color[][] getColoresTablero(){
        Color [][] matrizColores = new Color[boardHeight][boardWidth];
        for (int i = 0; i < boardHeight; i++){
            for (int j = 0; j < boardWidth; j++){
                matrizColores[i][j] = board[i + 1][j + 1].getBackground();
            }
        }
        for (int i = 0; i < boardHeight; i++){
            System.out.println(Arrays.toString(matrizColores[i]));
        }
        return matrizColores;
    }

//    public void exporte(File archivo) throws FileNotFoundException {
//        int [][] matrizColores = new int[boardHeight][boardWidth];
//        for (int i = 0; i < boardHeight; i++){
//            for (int j = 0; j < boardWidth; j++){
//                matrizColores[i][j] = board[i + 1][j + 1].getBackground().getRGB();
//            }
//        }
//        PrintWriter printWriter = new PrintWriter(new FileOutputStream(archivo));
//        for(int[] colorFila : matrizColores){
//            String newFila = "";
//            for (int color : colorFila){
//                newFila += (color + " " );
//            }
//            printWriter.println(newFila);
//        }
//        printWriter.println("");
//        for(int[] fila : logictetris.getTablero()){
//            String newFila = "";
//            for (int num : fila){
//                newFila += (num + " ");
//            }
//            printWriter.println(newFila);
//        }
//        printWriter.close();
//    }

    public void exporte(File archivo)  {
        ObjectOutputStream salida = null;
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(archivo);
            salida = new ObjectOutputStream(fos);
            salida.writeObject(this);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    public Tablero importe(File archivo) throws IOException, ClassNotFoundException {
        try {
            ObjectInputStream archivoTablero = new ObjectInputStream(new FileInputStream(archivo));
            Tablero tableroCargado = (Tablero) archivoTablero.readObject();
            archivoTablero.close();
            this. =  tableroCargado;
        } catch (IOException | ClassNotFoundException e) {
           throw e;
        }
    }

//    public void importe(File archivo) throws IOException {
//        BufferedReader bIn = new BufferedReader(new FileReader(archivo));
////        botonesTablero = new JPanel();
////        botonesTablero.setLayout(new GridLayout(boardHeight + 2, boardWidth + 2,0, 0));
////        int fila = 0;
////        while (!Objects.equals(line, "")) {
////            for (int i = 0; i < newLinea.length; i ++){
////                System.out.println(i + " " + newLinea[i] + " " + newLinea.length + " " + boardWidth + 2);
////            }
//        String lineColor = "";
//        String[] newLineaColor = {""};
//        for (int i = 0; i < boardHeight + 2; i++){ //(JPanel[] lineaBotones : board) {
//            if (i != 0 && i != boardHeight + 1){
//                lineColor = bIn.readLine();
//                lineColor = lineColor.trim();
//                newLineaColor = lineColor.split(" ");
//            }
//            for (int j = 0; j < boardWidth + 2; j++) {
//                if (i == 0 || i == boardHeight + 1 || j == 0 || j == boardWidth + 1) {
//                    board[i][j].setBackground(colorBorde);
//                }
//                else{
////                        System.out.println("alo " + new Color(Integer.parseInt(newLinea[j - 1])));
//                    if (!Objects.equals(newLineaColor[j-1], "")) board[i][j].setBackground(new Color(Integer.parseInt(newLineaColor[j - 1])));
//                }
//                board[i][j] = board[i][j];
//                botonesTablero.add(board[i][j]);
//            }
//        }
//        String logicLine = bIn.readLine();
//        logicLine = bIn.readLine();
//        logicLine = logicLine.trim();
//        int fila = 0;
//        int[][] newMatrizTetris = new int[boardHeight][boardWidth];
//        while (logicLine != null && !Objects.equals(logicLine, " ")){
//            logicLine = logicLine.trim();
//            String[] logicNewLine = logicLine.split(" ");
//            int[] logicIntLine = new int[boardWidth];
//            for (int i = 0 ; i < boardWidth ; i++){
////                System.out.println(Arrays.toString(logicNewLine));
////                System.out.println("alo " + Integer.parseInt(logicNewLine[i]) + " " + i);//logicNewLine[i]);//
//                if (!Objects.equals(logicNewLine[i], "")) logicIntLine[i] = Integer.parseInt(logicNewLine[i]);
//            }
//            newMatrizTetris[fila] = logicIntLine;
//            fila += 1;
//            logicLine = bIn.readLine();
//        }
////        changeColors();
////        }
//        Tetris newLogicTetris = new Tetris(newMatrizTetris);
//        logictetris = newLogicTetris;
////        logictetris.nuevafigura();
//    }

    private void juegue(ActionEvent actionEvent) {
        logictetris.figura.abajo();
        if (!logictetris.terminoficha()) {
            logictetris.nuevafigura();
        }
        if (logictetris.terminojuego()) {
            timer.stop();
            JOptionPane.showMessageDialog(null, "Buen intento crack", "TERMINO EL JUEGO", JOptionPane.INFORMATION_MESSAGE);
        }
        changeColors();
    }

    public void Derecha(){
//        movimiento = "Derecha";
        logictetris.figura.mueveDerecha();
        changeColors();
    }

    public void Izquierda(){
//        movimiento = "Izquierda";
        logictetris.figura.mueveIzquierda();
        changeColors();
    }

    public void Rote(){
//        movimiento = "Rote";
        logictetris.figura.nextState();
        changeColors();
    }

    public void baje(){
        logictetris.figura.abajo();
        changeColors();
    }

    public void pausa(){
        this.pausa= !pausa;
        if(!pausa){
            timer.stop();
        }else{
            timer.start();
        }
    }

}
