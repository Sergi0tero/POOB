package Presentacion;

import Dominio.*;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Class TetrisGUI
 *
 * @author  Archila-Otero
 */
public class TetrisGUI extends JFrame implements ActionListener, KeyListener {

    //Int
    private int height;
    private int width;
    private final int boardheight = 20;
    private final int boardwidth = 10;
    private boolean Dosplayers = false;

    //String
    private String lastTablero;

    //JMenu
    private JMenuBar menuBar = new JMenuBar();
    private final JMenu menu = new JMenu("Menu");

    private final JMenuItem nuevo = new JMenuItem("Nuevo");
    private final JMenuItem abrir = new JMenuItem("Abrir");
    private final JMenuItem salvar = new JMenuItem("Salvar");
    private final JMenuItem salir = new JMenuItem("Salir");

    //JLabel
    private JLabel namePlayer;
    private JLabel name1;
    private JLabel name2;
    private JLabel puntuacion;

    //JPanel
    private JPanel home;
    private JPanel elegirModo;
    private JPanel tablero1Jugador;
    private JPanel tablero2jugadores;
    private JPanel config;
    private JPanel cambieColorMenu;
    private JPanel cambieColorPerfilMenu;

    //Tablero
    private Tablero board1Jugador;
    private Tablero boardMulti1;
    private Tablero boardMulti2;

    //JButton
    private JButton homeJugar;
    private JButton homeSalir;
    private JButton modoUnJugador;
    private JButton modoDosJugadores;
    private JButton modoJugadorMaquina;
    private JButton volverArrow;
    private JButton pauseButton1J;
    private JButton pauseButton2J;
    private JButton configVolverJuego;
    private JButton configCambiarColor;
    private JButton configCambiarNombre;
    private JButton configSalirMenu;
    private JButton volverConfigCambieColor;
    private JButton volverConfigCambiePerfil;
    private JButton cambiarColorPerfil;
    private JButton cambiarColorBackGround;
    private JButton cambiarColorPerfilNickname;
    private JButton cambiarColorPerfilBackground;

    /*
    Constructor de TetrisGUI
     */
    private TetrisGUI(){
        super("Tetris");
        prepareElementos();
        prepareAcciones();
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

    }

    /*
    Funcion main de TetrisGUI
     */
    public static void main(String[] args){
        TetrisGUI tetrisGUI = new TetrisGUI();
        tetrisGUI.setVisible(true);
    }

    /*
    Prepara todos los elementos necesarios para el juego
     */
    private void prepareElementos(){
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        this.height = (int)screen.getHeight();
        this.width = (int)screen.getWidth();
        setSize(width/2, height/2);
        setLocation(width/4, height/4);
        setFocusable(true);
        Image logo = Toolkit.getDefaultToolkit().getImage("./images/Iconos/tetrisLogo.png");
        setIconImage(logo);
        prepareElementosMenu();
        prepareElementosHome();
        prepareElementosElegirModo();
        prepareElementosTableroUnJugador();
        prepareElementosTableroDosJugadores();
        prepareElementosConfig();
        prepareElementosCambieColor();
        prepareElementosMenuCambiePerfil();
        add(home);
    }

    /*
    Prepara y añade todos los botones al menu del juego
     */
    private void prepareElementosMenu(){
        setJMenuBar(menuBar);

        menuBar.add(menu);
        menu.add(nuevo);
        menu.add(abrir);
        menu.add(salvar);
        menu.add(salir);
    }

    /*
    Nueva clase que extiende a JPanel para poder poner una imagen como fondo
     */
    class FondoJpanel extends JPanel{
        private final String imageUrl;

        /*
        Constructor de la clase JPanel
         */
        public FondoJpanel(String imageUrl){
            this.imageUrl = imageUrl;
        }

        /*
        Se hace un Override de la funcion paint, dejando añadir una imagen
         */
        @Override
        public void paint(Graphics g) {
            Image imagen = new ImageIcon(imageUrl).getImage();
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
            setOpaque(false);
            super.paint(g);
        }
    }

    /*
    Prepara los elementos (JButton, JPanel y Fondos) del menu principal
     */
    private void prepareElementosHome(){
        FondoJpanel fondo = new FondoJpanel("./images/Fondos/menuFondo.gif");
        fondo.setBounds(0, 0, width /2, height /2);

        home = new JPanel();
        home.setLayout(null);

        FondoJpanel tetrisLogo = new FondoJpanel("./images/Iconos/tetrisLogo.png");
        tetrisLogo.setBounds((width/4) - 150, 30, 300, 209);
        home = new JPanel();
        home.setLayout(null);

        homeJugar = new JButton("Jugar");
        homeJugar.setFont(new Font("Magneto", Font.BOLD, 20));
        homeJugar.setBackground(Color.BLACK);
        homeJugar.setForeground(Color.MAGENTA);
        homeJugar.setBounds((width/4) - 75, height/4, 150, 35);
        home.add(homeJugar);

        homeSalir = new JButton("Salir");
        homeSalir.setFont(new Font("Magneto", Font.BOLD, 20));
        homeSalir.setBackground(Color.BLACK);
        homeSalir.setForeground(Color.MAGENTA);
        homeSalir.setBounds((width/4) - 75, (height/4)+50, 150, 35);
        home.add(homeSalir);

        home.setBackground(Color.BLACK);
        home.add(tetrisLogo);
        home.add(fondo);
        add(home);
    }

    /*
    Prepara los elementos (JButton, JPanel y Fondos) del menu en el que el usuario elige el modo que quiere jugar (Un
    Jugador, Dos Jugadores, Jugador VS CPU)
     */
    private void prepareElementosElegirModo(){
        elegirModo = new JPanel();
        elegirModo.setLayout(null);

        modoUnJugador = new JButton("Un Jugador");
        modoUnJugador.setFont(new Font("Magneto", Font.BOLD, 16));
        modoUnJugador.setBackground(Color.BLACK);
        modoUnJugador.setForeground(Color.MAGENTA);
        modoUnJugador.setBounds((width/4) - 75, height/4, 150, 35);
        elegirModo.add(modoUnJugador);

        modoDosJugadores = new JButton("Jugador VS Jugador");
        modoDosJugadores.setFont(new Font("Magneto", Font.BOLD, 16));
        modoDosJugadores.setBackground(Color.BLACK);
        modoDosJugadores.setForeground(Color.MAGENTA);
        modoDosJugadores.setBounds((width/4) - 110, (height/4) + 50, 220, 35);
        elegirModo.add(modoDosJugadores);

        modoJugadorMaquina = new JButton("Jugador VS CPU");
        modoJugadorMaquina.setFont(new Font("Magneto", Font.BOLD, 16));
        modoJugadorMaquina.setBackground(Color.BLACK);
        modoJugadorMaquina.setForeground(Color.MAGENTA);
        modoJugadorMaquina.setBounds((width/4) - 90, (height/4) + 100, 180, 35);
        elegirModo.add(modoJugadorMaquina);

        volverArrow = new JButton();
        volverArrow.setIcon(new ImageIcon("./images/Botones/blueArrow.png"));
        volverArrow.setBounds(0, 0, 50, 56);
        volverArrow.setBorderPainted(false);
        volverArrow.setContentAreaFilled(false);
        volverArrow.setFocusPainted(false);
        volverArrow.setOpaque(false);
        elegirModo.add(volverArrow);

        FondoJpanel fondo = new FondoJpanel("./images/Fondos/elegirModoFondo.gif");
        fondo.setBounds(0, 0, width /2, height /2);
        elegirModo.add(fondo);
    }

    /*
    Prepara los elementos (JButton, tablero, JPanel y Fondos) del modo Un Jugador
     */
    private void prepareElementosTableroUnJugador() {
        tablero1Jugador = new JPanel();
        tablero1Jugador.setLayout(null);

        namePlayer = new JLabel("Jugador1", SwingConstants.CENTER);
        namePlayer.setBounds((this.getWidth()/2)-50, 0, 100,35);
        namePlayer.setForeground(Color.BLUE);
        namePlayer.setBackground(Color.BLACK);
        namePlayer.setOpaque(true);
        namePlayer.setFont(new Font("Magneto", Font.BOLD, 15));
        tablero1Jugador.add(namePlayer);

        board1Jugador = new Tablero();
        JPanel board = board1Jugador.createGame(boardheight, boardwidth, getWidth(), getHeight());
        tablero1Jugador.add(board);
        tablero1Jugador.setVisible(false);

        puntuacion = new JLabel("Puntuacion: 0", SwingConstants.CENTER);
        puntuacion.setBounds(0, (this.getHeight()/2)-50, 200,35);
        puntuacion.setForeground(Color.BLUE);
        puntuacion.setBackground(Color.BLACK);
        puntuacion.setOpaque(true);
        puntuacion.setFont(new Font("Magneto", Font.BOLD, 15));
        board1Jugador.setPuntuacion(puntuacion);
        tablero1Jugador.add(puntuacion);

        pauseButton1J = new JButton();
        pauseButton1J.setIcon(new ImageIcon("./images/Botones/pause.png"));
        pauseButton1J.setBounds(this.getWidth()-75, 0, 50, 50);
        pauseButton1J.setBorderPainted(false);
        pauseButton1J.setContentAreaFilled(false);
        pauseButton1J.setFocusPainted(false);
        pauseButton1J.setOpaque(false);
        tablero1Jugador.add(pauseButton1J);

        FondoJpanel fondo = new FondoJpanel("./images/Fondos/unJugadorFondo.gif");
        fondo.setBounds(0, 0, width /2, height /2);
        tablero1Jugador.add(fondo);
    }

    /*
    Prepara los elementos (JButton, tableros, JPanel y Fondos) del modo Dos Jugador
     */
    private void prepareElementosTableroDosJugadores() {
        tablero2jugadores = new JPanel();
        tablero2jugadores.setLayout(null);

        name1 = new JLabel("Jugador1", SwingConstants.CENTER);
        name1.setForeground(Color.BLUE);
        name1.setBackground(Color.BLACK);
        name1.setOpaque(true);
        name1.setFont(new Font("Magneto", Font.BOLD, 15));
        name1.setBounds(((this.getWidth()/2)-(this.getWidth()/4)) - 50, 0, 100,35);
        name2 = new JLabel("Jugador2", SwingConstants.CENTER);
        name2.setForeground(Color.BLUE);
        name2.setBackground(Color.BLACK);
        name2.setOpaque(true);
        name2.setFont(new Font("Magneto", Font.BOLD, 15));
        name2.setBounds(((this.getWidth()/2)+(this.getWidth()/4)) - 50, 0, 100,35);
        tablero2jugadores.add(name1);
        tablero2jugadores.add(name2);

        boardMulti1 = new Tablero();
        boardMulti2 = new Tablero();
        JPanel board = boardMulti1.createGame(boardheight, boardwidth, getWidth(), getHeight());
        JPanel board2 = boardMulti2.createGame(boardheight, boardwidth, getWidth(), getHeight());
        board.setBounds(((this.getWidth()/2)-(this.getWidth()/4)) - getWidth()/8, 40, getWidth()/4,(getHeight()*3)/4);
        board2.setBounds(((this.getWidth()/2)+(this.getWidth()/4))- getWidth()/8, 40, getWidth()/4,(getHeight()*3)/4);
        tablero2jugadores.add(board);
        tablero2jugadores.add(board2);
        tablero2jugadores.setVisible(false);

        pauseButton2J = new JButton();
        pauseButton2J.setIcon(new ImageIcon("./images/Botones/pause.png"));
        pauseButton2J.setBounds(this.getWidth()-75, 0, 50, 50);
        pauseButton2J.setBorderPainted(false);
        pauseButton2J.setContentAreaFilled(false);
        pauseButton2J.setFocusPainted(false);
        pauseButton2J.setOpaque(false);
        tablero2jugadores.add(pauseButton2J);

        FondoJpanel fondo = new FondoJpanel("./images/Fondos/unJugadorFondo.gif");
        fondo.setBounds(0, 0, width /2, height /2);
        tablero2jugadores.add(fondo);
    }

    /*
    Prepara los elementos (JButton, JPanel y Fondos) del menu de configuracion
     */
    private void prepareElementosConfig(){
        config = new JPanel();
        config.setLayout(null);

        configVolverJuego = new JButton("Volver al juego");
        configVolverJuego.setFont(new Font("Magneto", Font.BOLD, 15));
        configVolverJuego.setBackground(Color.BLACK);
        configVolverJuego.setForeground(Color.MAGENTA);
        configVolverJuego.setBounds((this.getWidth()*2/10) - 100, this.getHeight()/10, 200, 35);
        config.add(configVolverJuego);

        configCambiarColor = new JButton("Cambiar colores");
        configCambiarColor.setFont(new Font("Magneto", Font.BOLD, 15));
        configCambiarColor.setBackground(Color.BLACK);
        configCambiarColor.setForeground(Color.MAGENTA);
        configCambiarColor.setBounds((this.getWidth()*5/10) - 100, this.getHeight()*2/10, 200, 35);
        config.add(configCambiarColor);

        configCambiarNombre = new JButton("Cambiar nombre");
        configCambiarNombre.setFont(new Font("Magneto", Font.BOLD, 15));
        configCambiarNombre.setBackground(Color.BLACK);
        configCambiarNombre.setForeground(Color.MAGENTA);
        configCambiarNombre.setBounds((this.getWidth()*8/10) - 90, this.getHeight()*3/10, 180, 35);
        config.add(configCambiarNombre);

        configSalirMenu = new JButton("Salir");
        configSalirMenu.setFont(new Font("Magneto", Font.BOLD, 15));
        configSalirMenu.setBackground(Color.BLACK);
        configSalirMenu.setForeground(Color.MAGENTA);
        configSalirMenu.setBounds((this.getWidth()*8/10) - 75, this.getHeight()-150, 150, 35);
        config.add(configSalirMenu);

        JLabel configTitulo = new JLabel("Configuraciones", SwingConstants.CENTER);
        configTitulo.setBounds(getWidth()*3/10 - 160, getHeight()*5/11 - 18, 320,36);
        configTitulo.setForeground(Color.MAGENTA);
        configTitulo.setFont(new Font("Matura MT Script Capitals", Font.BOLD, 42));
        config.add(configTitulo);

        FondoJpanel fondo = new FondoJpanel("./images/Fondos/configFondo.gif");
        fondo.setBounds(0, 0, width /2, height /2);
        config.add(fondo);
    }

    /*
    Prepara los elementos (JButton, JPanel y Fondos) del menu de configuracion de los colores del juego
     */
    private void prepareElementosCambieColor(){
        cambieColorMenu = new JPanel();
        cambieColorMenu.setLayout(null);

        volverConfigCambieColor = new JButton("Volver");
        volverConfigCambieColor.setFont(new Font("Magneto", Font.BOLD, 15));
        volverConfigCambieColor.setBackground(Color.BLACK);
        volverConfigCambieColor.setForeground(Color.MAGENTA);
        volverConfigCambieColor.setBounds((this.getWidth()*2/10) - 50, this.getHeight()/10, 100, 35);
        cambieColorMenu.add(volverConfigCambieColor);

        cambiarColorPerfil = new JButton("Cambiar color del Perfil");
        cambiarColorPerfil.setFont(new Font("Magneto", Font.BOLD, 15));
        cambiarColorPerfil.setBackground(Color.BLACK);
        cambiarColorPerfil.setForeground(Color.MAGENTA);
        cambiarColorPerfil.setBounds((this.getWidth()*5/10) - 125, this.getHeight()*2/10, 250, 35);
        cambieColorMenu.add(cambiarColorPerfil);

        cambiarColorBackGround = new JButton("Cambiar color del fondo");
        cambiarColorBackGround.setFont(new Font("Magneto", Font.BOLD, 15));
        cambiarColorBackGround.setBackground(Color.BLACK);
        cambiarColorBackGround.setForeground(Color.MAGENTA);
        cambiarColorBackGround.setBounds((this.getWidth()*8/10) - 125, this.getHeight()*3/10, 250, 35);
        cambieColorMenu.add(cambiarColorBackGround);

        JLabel coloresTitulo = new JLabel("Colores", SwingConstants.CENTER);
        coloresTitulo.setBounds(getWidth()*3/10 - 160, getHeight()*5/11 - 18, 320,36);
        coloresTitulo.setForeground(Color.MAGENTA);
        coloresTitulo.setFont(new Font("Matura MT Script Capitals", Font.BOLD, 42));
        cambieColorMenu.add(coloresTitulo);

        FondoJpanel fondo = new FondoJpanel("./images/Fondos/configFondo.gif");
        fondo.setBounds(0, 0, width /2, height /2);
        cambieColorMenu.add(fondo);
    }

    /*
    Prepara los elementos (JButton, JPanel y Fondos) del menu de configuracion de los colores del perfil (Nombre y fondo
    del jugador)
     */
    private void prepareElementosMenuCambiePerfil(){
        cambieColorPerfilMenu = new JPanel();
        cambieColorPerfilMenu.setLayout(null);

        volverConfigCambiePerfil = new JButton("Volver");
        volverConfigCambiePerfil.setFont(new Font("Magneto", Font.BOLD, 15));
        volverConfigCambiePerfil.setBackground(Color.BLACK);
        volverConfigCambiePerfil.setForeground(Color.MAGENTA);
        volverConfigCambiePerfil.setBounds((this.getWidth()*2/10) - 50, this.getHeight()/10, 100, 35);
        cambieColorPerfilMenu.add(volverConfigCambiePerfil);

        cambiarColorPerfilNickname = new JButton("Cambiar color Nickname");
        cambiarColorPerfilNickname.setFont(new Font("Magneto", Font.BOLD, 15));
        cambiarColorPerfilNickname.setBackground(Color.BLACK);
        cambiarColorPerfilNickname.setForeground(Color.MAGENTA);
        cambiarColorPerfilNickname.setBounds((this.getWidth()*5/10) - 125, this.getHeight()*2/10, 250, 35);
        cambieColorPerfilMenu.add(cambiarColorPerfilNickname);

        cambiarColorPerfilBackground = new JButton("Cambiar color del fondo");
        cambiarColorPerfilBackground.setFont(new Font("Magneto", Font.BOLD, 15));
        cambiarColorPerfilBackground.setBackground(Color.BLACK);
        cambiarColorPerfilBackground.setForeground(Color.MAGENTA);
        cambiarColorPerfilBackground.setBounds((this.getWidth()*8/10) - 125, this.getHeight()*3/10, 250, 35);
        cambieColorPerfilMenu.add(cambiarColorPerfilBackground);

        JLabel perfilesTitulo = new JLabel("Cambio Perfil", SwingConstants.CENTER);
        perfilesTitulo.setBounds(getWidth()*3/10 - 160, getHeight()*5/11 - 18, 320,36);
        perfilesTitulo.setForeground(Color.MAGENTA);
        perfilesTitulo.setFont(new Font("Matura MT Script Capitals", Font.BOLD, 42));
        cambieColorPerfilMenu.add(perfilesTitulo);

        FondoJpanel fondo = new FondoJpanel("./images/Fondos/configFondo.gif");
        fondo.setBounds(0, 0, width /2, height /2);
        cambieColorPerfilMenu.add(fondo);
    }

    /*
    Añade los oyentes de todos los botones utilizados en el Juego
     */
    private void prepareAcciones(){
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent w) {
                salga();
            }
        });
        abrir.addActionListener(this);
        salvar.addActionListener(this);
        salir.addActionListener(this);
        homeJugar.addActionListener(this);
        modoUnJugador.addActionListener(this);
        modoDosJugadores.addActionListener(this);
        homeSalir.addActionListener(this);
        volverArrow.addActionListener(this);
        pauseButton1J.addActionListener(this);
        pauseButton2J.addActionListener(this);
        configVolverJuego.addActionListener(this);
        configCambiarColor.addActionListener(this);
        configSalirMenu.addActionListener(this);
        configCambiarNombre.addActionListener(this);
        cambiarColorBackGround.addActionListener(this);
        volverConfigCambieColor.addActionListener(this);
        volverConfigCambiePerfil.addActionListener(this);
        cambiarColorPerfil.addActionListener(this);
        cambiarColorPerfilNickname.addActionListener(this);
        cambiarColorPerfilBackground.addActionListener(this);
        this.addKeyListener(this);
    }

    /*
    Añade las acciones de todos los botones utilizados en el Juego
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==abrir) abra();
        if (e.getSource()==salvar) salve();
        if (e.getSource()==salir) salga();
        if (e.getSource()==homeJugar) jugar();
        if (e.getSource()==modoUnJugador) unJugador();
        if (e.getSource()==modoDosJugadores) dosjugadores();
        if (e.getSource()==homeSalir) salga();
        if (e.getSource()==volverArrow || e.getSource()==configSalirMenu) vuelvaMenu();
        if (e.getSource()==pauseButton1J || e.getSource()==pauseButton2J || e.getSource()==volverConfigCambieColor || e.getSource()==volverConfigCambiePerfil) abraConfig();
        if (e.getSource()==configCambiarColor) abraCambieColorMenu();
        if (e.getSource()==configVolverJuego) vuelvaJuego();
        if (e.getSource()==cambiarColorBackGround) cambieColorFondo();
        if (e.getSource()==configCambiarNombre) cambieNombre();
        if (e.getSource()==cambiarColorPerfil) cambieColorPerfil();
        if (e.getSource()==cambiarColorPerfilNickname) cambieColorPerfilNickname();
        if (e.getSource()==cambiarColorPerfilBackground) cambieColorPerfilBackground();

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyChar() == 'w'){
            if(!Dosplayers) {
                board1Jugador.Rote();
            }else{
                boardMulti1.Rote();
            }
        }if(e.getKeyChar() == 'a'){
            if(!Dosplayers) {
                board1Jugador.Izquierda();
            }else {
                boardMulti1.Izquierda();
            }
        }if(e.getKeyChar() == 's'){
            if(!Dosplayers) {
                board1Jugador.baje();
            }else{
                boardMulti1.baje();
            }
        }if(e.getKeyChar() == 'd'){
            if(!Dosplayers) {
                board1Jugador.Derecha();
            }else{
                boardMulti1.Derecha();
            }
        }if(Dosplayers) {
            if (e.getKeyCode() == KeyEvent.VK_UP) {
                boardMulti2.Rote();
            }
            if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                boardMulti2.Izquierda();
            }
            if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                boardMulti2.Derecha();
            }
            if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                boardMulti2.baje();
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    /*
    Accion del menu para abrir un archivo
     */
    private void abra(){
        try {
            JFileChooser filepath = new JFileChooser();
            filepath.setFileFilter(new FileNameExtensionFilter(null, "dat"));
            filepath.showDialog(null, "Importar");
            filepath.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
            board1Jugador.importe(filepath.getSelectedFile());
        } catch (IOException | ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    /*
    Accion del menu para guardar un archivo
     */
    private void salve(){
        JFileChooser filepath = new JFileChooser();
        filepath.setFileFilter(new FileNameExtensionFilter(null, "dat"));
        filepath.showDialog(null, "Guardar");
        filepath.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        board1Jugador.exporte(filepath.getSelectedFile());
    }

    /*
    Accion del menu para salir del juego
     */
    private void salga(){
        if (JOptionPane.showConfirmDialog(rootPane, "¿Seguro que quiere salir de Tetris?", "Exit", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) System.exit(0);
    }

    /*
    Accion del menu principar para entrar al menu de modos de juego
     */
    private void jugar(){
        add(elegirModo);
        home.setVisible(false);
        elegirModo.setVisible(true);
    }


    /*
    Inicia el juego en modo Un Jugador
     */
    private void unJugador(){
        String nombreJugador1 = JOptionPane.showInputDialog("Jugador: ");
        if (!nombreJugador1.isEmpty()){
            namePlayer.setText(nombreJugador1);
        }
        add(tablero1Jugador);
        elegirModo.setVisible(false);
        tablero1Jugador.setVisible(true);
        board1Jugador.inicie();
    }

    /*
    Inicia el juego en modo dos jugadores
     */
    private void dosjugadores(){
        Dosplayers = true;
        String nombreJugador1 = JOptionPane.showInputDialog("Jugador 1: ");
        String nombreJugador2 = JOptionPane.showInputDialog("Jugador 2: ");
        if (!nombreJugador1.isEmpty()){
            name1.setText(nombreJugador1);
        }
        if (!nombreJugador2.isEmpty()){
            name2.setText(nombreJugador2);
        }
        add(tablero2jugadores);
        elegirModo.setVisible(false);
        tablero2jugadores.setVisible(true);
        boardMulti1.inicie();
        boardMulti2.inicie();
    }

    /*
    Inicia le juego en modo Jugador VS CPU
     */
    private void contramaquina(){

    }

    /*
    Accion de volver al menu principal
     */
    private void vuelvaMenu(){
        if (JOptionPane.showConfirmDialog(rootPane, "Seguro que quiere salir de la partida?",
                "Salir del sistema", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (elegirModo.isVisible()) elegirModo.setVisible(false);
            else if (config.isVisible()) config.setVisible(false);
            home.setVisible(true);
        }
    }

    /*
    Accion para abrir las configuraciones del juego
     */
    private void abraConfig(){
        if (tablero1Jugador.isVisible()){
            lastTablero = "1J";
            tablero1Jugador.setVisible(false);
            board1Jugador.pausa();
        }
        else if (tablero2jugadores.isVisible()){
            lastTablero = "2J";
            tablero2jugadores.setVisible(false);
        }
        else if (cambieColorMenu.isVisible()) cambieColorMenu.setVisible(false);
        else if (cambieColorPerfilMenu.isVisible()) cambieColorPerfilMenu.setVisible(false);
        add(config);
        config.setVisible(true);
    }

    /*
    Accion para volver al juego
     */
    private void vuelvaJuego(){
        config.setVisible(false);
        if (lastTablero == "1J"){
            board1Jugador.pausa();
            tablero1Jugador.setVisible(true);
        }
        if (lastTablero == "2J") tablero2jugadores.setVisible(true);
    }

    /*
    Accion para iniciar el menu de cambio de color
     */
    private void abraCambieColorMenu(){
        config.setVisible(false);
        add(cambieColorMenu);
        cambieColorMenu.setVisible(true);
    }

    /*
    Accion para cambiar el nombre de el(los) jugador(es)
     */
    private void cambieNombre(){
        if (lastTablero == "1J"){
            String nombreJugador1 = JOptionPane.showInputDialog("Jugador: ");
            if (!nombreJugador1.isEmpty()){
                namePlayer.setText(nombreJugador1);
            }
        }
        else if (lastTablero == "2J"){
            String nombreJugador1 = JOptionPane.showInputDialog("Jugador 1: ");
            String nombreJugador2 = JOptionPane.showInputDialog("Jugador 2: ");
            if (!nombreJugador1.isEmpty()){
                name1.setText(nombreJugador1);
            }
            if (!nombreJugador2.isEmpty()){
                name2.setText(nombreJugador2);
            }
        }
    }

    /*
    Accion para Cambiar el color del fondo del juego
     */
    private void cambieColorFondo(){
        Color color = JColorChooser.showDialog(null, "Seleccione un color para las fichas", board1Jugador.getColorFondo());
        if (lastTablero == "1J") board1Jugador.changeColorBackGround(color);
        if (lastTablero == "2J"){
            boardMulti1.changeColorBackGround(color);
            boardMulti2.changeColorBackGround(color);
        }
    }

    /*
    Accion para abrir el menu del menu para hacer el cambio de los colores del perfil del jugador
     */
    private void cambieColorPerfil(){
        cambieColorMenu.setVisible(false);
        add(cambieColorPerfilMenu);
        cambieColorPerfilMenu.setVisible(true);
    }

    /*
    Accion para cambiar el color del nombre de el(los) jugador(es)
     */
    private void cambieColorPerfilNickname(){
        Color color = JColorChooser.showDialog(null, "Seleccione un color para las fichas", board1Jugador.getColorFondo());
        if (lastTablero == "1J") namePlayer.setBackground(color);
        if (lastTablero == "2J"){
            name1.setBackground(color);
            name2.setBackground(color);
        }
    }

    /*
    Accion para cambiar el color del fondo del perfil de el(los) jugador(es)
     */
    private void cambieColorPerfilBackground() {
        Color color = JColorChooser.showDialog(null, "Seleccione un color para las fichas", board1Jugador.getColorFondo());
        if (lastTablero == "1J") namePlayer.setForeground(color);
        if (lastTablero == "2J") {
            name1.setForeground(color);
            name2.setForeground(color);
        }
    }
}
