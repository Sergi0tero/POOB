import java.util.ArrayList;

public abstract class User extends Taggable{
    private String nickName;
    private String phone;
    private ArrayList<Message> messages;
    public void tag (ArrayList<Tag> tags){
    
    };
}
