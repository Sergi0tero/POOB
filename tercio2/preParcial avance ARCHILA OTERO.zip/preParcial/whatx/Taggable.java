import java.util.*;
public abstract class Taggable
{
    // instance variables - replace the example below with your own
    int x;

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y    a sample parameter for a method
     * @return        the sum of x and y 
     */
    public abstract void tag (ArrayList<Tag> tags) throws Exception;
}
