public class Socket {
	
        public Socket(String host, int port) {
	}

	public void start() {
	}

	public void sendMessage(String fromPhone, String toPhone, String chatName, String text) {
	}

	public void addListener(Object listener) {
	}

	public void stop() {
	}

	public boolean deleteMessage(String toPhone, String chatName, int messageId) {
		return false;
	}
}
