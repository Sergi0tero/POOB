public class File {
	private String path;
	private String extension;
}
