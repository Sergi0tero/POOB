
public class Person extends User {

	private String about;
}
