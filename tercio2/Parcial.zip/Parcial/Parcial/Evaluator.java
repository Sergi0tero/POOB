public abstract class Evaluator {

    private Requirement requirement;

    /**
     *  
     */
    public abstract int evaluate(Requirement r, String appUrl);

}
