import java.time.LocalDate;
import java.util.Collection;

public class Inscription {

	private LocalDate date;

	private String appUrl;

	private SwFactory swFactory;

	private Team team;

	private Project project;

	private Collection<Evaluation> evaluations;

	private Project project;

	private Collection<Notification> notifications;

}
