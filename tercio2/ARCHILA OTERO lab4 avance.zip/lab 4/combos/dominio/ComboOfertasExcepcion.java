package dominio;


/**
 * Clase de excepcion de Combo
 * 
 * @author Archila Otero
 */
public class ComboOfertasExcepcion extends Exception
{
    /*Errores del combo*/
    public final static String COMBO_VACIO = "Este combo esta vacio";
    
    /*Errores del producto*/
    public final static String PRODUCTO_SIN_PRECIO = "Este producto no tiene precio";
    public final static String PRODUCTO_ERROR_PRECIO = "Se produjo un error en el precio";
    
    public ComboOfertasExcepcion(String message){
        super(message);
    }
}
