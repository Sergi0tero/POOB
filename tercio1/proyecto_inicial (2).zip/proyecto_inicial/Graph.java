import java.util.ArrayList;
import java.util.Arrays;

public class Graph {
    
    private int nations;
    private ArrayList<Double> costos;
    private String[] camino;
    private ArrayList<String> vertices;
    private static int[][] ways;
    private boolean[] isVisited;
    private ArrayList<String> nationColor;
    public  Graph(int nations){
        this.nations = nations;
        vertices = new ArrayList<String>(nations);
        ways  = new int[5][5];
        isVisited = new boolean[7];
        costos = new ArrayList<Double>();
        camino = new String[5]; 
        nationColor = new ArrayList<String>();
        nationColor.add("red");
        nationColor.add("blue");
        nationColor.add("yellow");
        nationColor.add("green");
        nationColor.add("magenta");
        for (int i = 0; i <nations ; i++) {
            costos.add(Double.POSITIVE_INFINITY);
            vertices.add(nationColor.get(i));
            camino[i] = "";
        }
    }
    
    public int getIndex(String nation){
        return vertices.indexOf(nation);
    }

    public  void addNation(String nation){
        vertices.add(nation);
        costos.add(Double.POSITIVE_INFINITY);
        nations += 1;
    }
    
    public int firstNation(int index){
        for (int i = 0; i <vertices.size() -1 ; i++) {
            if (ways[index][i]>0) {
                return i;
            }
        }
        return nations;
    }
    
    public int nextNation(int index,int firstCO){
        for (int i =firstCO+1 ; i <vertices.size() - 1; i++) {
            if (ways[index][i]>0) {
                return i;
            }
        }
        return nations;
    }
    
    public  void addRoute(int nacion1,int nacion2 , int weight){
        ways[nacion1][nacion2] = weight;
        ways[nacion2][nacion1] = weight;
    }

    public String dijkstra(String salida, String objetivo){
        int index = getIndex(salida);
        int obj = getIndex(objetivo);
        reiniciar();
        int actualNation;
        costos.set(index, 0.0);
        while (!isVisited[index]){
            actualNation = firstNation(index);
            while(isVisited[actualNation]){
                actualNation = nextNation(index,actualNation);
            }
            if (actualNation==nations) {
                isVisited[index]=true;
            }
            else {
                while (!isVisited[actualNation]&&actualNation<nations) {
                    isVisited[index]=true;
                    double cost = costos.get(index)+ways[index][actualNation];
                    if (cost<costos.get(actualNation)) {
                        costos.set(actualNation, cost);
                        camino[actualNation] = camino[index]+","+vertices.get(index);
                    }
                    actualNation = nextNation(index, actualNation);
                }
            }
            index = indexGet(costos,isVisited);
        }
        for (int i = 0; i <nations - 1 ; i++) {
            camino[i] += vertices.get(i);
        }
        String res = "";
        for (int i = 0; i <nations - 1; i++) {
            if (i == obj){
                res = camino[i];
            }
        }
        return res;
    }
    
    public double getDistance(String colorF){
        for (int i = 0; i <vertices.size() -1 ; i++) {
            if(vertices.get(i) == colorF){
                return costos.get(i);   
            }
        }
        return Double.POSITIVE_INFINITY;
    }
    
    public String[] getCamino(String colorF){
        for (int i = 0; i < vertices.size() -1 ; i++) {
            if(vertices.get(i) == colorF){
                String finalWay[] = camino[i].split(" ");
                return finalWay;
            }
        }
        return null;
    }
    
    public void reiniciar()
    {
        for (int i = 0; i < nations - 1; i++) {
            costos.set(i, Double.POSITIVE_INFINITY);
        }
        for (int j = 0; j < nations - 1; j++) {
            System.out.println(j);
            camino[j] = "";
        }
        isVisited = new boolean[nations+1];
    }
    
    public int indexGet(ArrayList<Double> costos, boolean[] isVisited){
        int j=0;
        double mindis=Double.POSITIVE_INFINITY;
        for (int i = 0; i < costos.size(); i++) {
            if (!isVisited[i]){
                if(costos.get(i)<mindis){
                    mindis=costos.get(i);
                    j=i;
                }
            }
        }
        return j;
    }
}