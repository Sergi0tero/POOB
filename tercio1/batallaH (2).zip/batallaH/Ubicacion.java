 

public class Ubicacion {
    private int longitud;
    private int latitud;
    public Ubicacion(){
        
    }
    
    public int getLongitud(){
        return longitud;
    }
    
    public int getLatitud(){
        return latitud;
    }
    
    public void setLatitud(int latitud){
        this.latitud = latitud;
    }
    
    public void setLongitud(int longitud){
        this.longitud = longitud;
    }
}
