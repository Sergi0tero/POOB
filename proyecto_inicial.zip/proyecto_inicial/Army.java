
/**
 * Write a description of class Army here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Army
{
    private Circle zone;
    private int xPosition;
    private int yPosition;
    private String color;

    /**
     * Constructor for objects of class Army
     */
    public Army(int xPosition, int yPosition, String color){
        this.color = color;
        this.xPosition = xPosition;
        this.yPosition = yPosition;
        zone = new Circle();
        zone.changeColor("black");
        setArmy(xPosition, yPosition);
    }
    
    public String getNation(){
        return color;
    }
    
    /**
     * 
     */
    public void makeVisible(){
        zone.makeVisible();
    }
    
    public void makeInvisible(){
        zone.makeVisible();
    }
    
    private void setArmy(int x, int y){
        xPosition = x;
        yPosition = y;
        zone.moveTo(xPosition, yPosition);
        zone.makeVisible();
    }
}
