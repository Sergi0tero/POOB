import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 * Write a description of class World here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class World
{
    private String color;
    private ArrayList<String> nationColor;
    private ArrayList<Nation> nations;
    private String conquered[];
    private ArrayList<Route> routes;
    private ArrayList<Army> armies;
    private int totalCost;
    private Rectangle board;
    private int quantConquered;
    private boolean okas;
    
    /**
     * Constructor for objects of class World
     */
    public World(int lenght, int widht){
        board = new Rectangle();
        board.changeSize(lenght, widht);
        board.changeColor("black");
        board.makeVisible();
        totalCost = 0;
        quantConquered = 0;
        nations = new ArrayList<Nation>();
        nationColor = new ArrayList<String>();
        armies = new ArrayList<Army>();
        routes = new ArrayList<Route>();
    }

    /**
     * 
     */
    public void addNation(String color, int x, int y, int armies){
        if (!nationColor.contains(color)){
            if (color != "black" || color != "white"){
                Nation nation;
                nation = new Nation(color, x, y, armies);
                nations.add(nation);
                nations.get(nations.indexOf(nation)).makeVisible();
                if (armies > 0){
                    nations.get(nations.indexOf(nation)).armiesVisible();
                    okas = true;
                }
                else if (armies == 0){
                    nations.get(nations.indexOf(nation)).conquer();
                    nations.get(nations.indexOf(nation)).armyVisible();
                }
                nationColor.add(color);
            }
            else{
                okas = false;
            }
        }
        else {
            okas = false;
        }
    }
    
    public void delNation(String color){
        for (int i = 0; i < nations.size(); i++){
            if (nations.get(i).getColor() == color ){
                nations.get(i).makeInvisible();
                nations.remove(nations.get(i));
                nationColor.remove(color);
                okas = true;
            }
        }
    }
    
    public void addRoute(String locationA, String locationB, int cost){
        int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
        for (int i = 0; i < nations.size(); i++){
            if (locationA != locationB){
                if(nations.get(i).getColor() == locationA){
                    x1 = nations.get(i).getX();
                    y1 = nations.get(i).getY();
                }
                else if(nations.get(i).getColor() == locationB){
                    x2 = nations.get(i).getX();
                    y2 = nations.get(i).getY();
                }
            }
        }
        Route route;
        route = new Route(x1 + 25, y1 + 25, x2 + 25, y2 + 25, cost);
        routes.add(route);
        routes.get(routes.indexOf(route)).makeVisible();
        okas = true;
    }

    public void delStreet(String locationA, String locationB){
        int x1 = -1, y1 = -1, x2 = -1, y2 = -1;
        for (int i = 0; i < nations.size(); i++){
            if(nations.get(i).getColor() == locationA ){
                x1 = nations.get(i).getX();
                y1 = nations.get(i).getY();
            }
            else if(nations.get(i).getColor() == locationB){
                x2 = nations.get(i).getX();
                y2 = nations.get(i).getY();
            }
        }
        if (x1 != -1 && x2 != -1 && y1 != -1 && y2 != -1){
            okas = true;
        }
        else{
            okas = false;
        }
    }
    
    public void putArmy(String color){
        for(int i  = 0; i < nations.size(); i++){
            if (nations.get(i).getColor() == color){
                nations.get(i).sumArmy();
            }
        }
    }
    
    public void removeArmy(String color){
        okas = false;
        for(int i  = 0; i < nations.size(); i++){
            if (nations.get(i).getColor() == color){
                nations.get(i).substractArmy();
                okas = true;
            }
        }
    }
    
    private void removeDefense(String color){
        okas = false;
        for(int i  = 0; i < nations.size(); i++){
            if (nations.get(i).getColor() == color){
                nations.get(i).substractDefense();
                okas = true;
            }
        }
    }
    
    public void moveArmyOneRoute(String locationA, String locationB){
        int x1 = 0, y1 = 0, x2 = 0, y2 = 0, nation1 = 0, nation2 = 0;
        boolean exist = false;
        for (int i = 0; i < nations.size(); i++){
            if(nations.get(i).getColor() == locationA ){
                x1 = nations.get(i).getX();
                y1 = nations.get(i).getY();
                nation1 = i;
            }
            else if(nations.get(i).getColor() == locationB){
                x2 = nations.get(i).getX();
                y2 = nations.get(i).getY();
                nation2 = i;
            }
        }
        
        for (int i = 0; i < routes.size(); i++){
            if (routes.get(i).isRoute(x1 + 25, y1 + 25, x2 + 25, y2 + 25)){
                totalCost += routes.get(i).getCost();
                exist = true;
                okas = true;
            }
            else{
                okas = false;
            }
        }
        
        if (exist == true && nations.get(nation1).getArmy() > 0){
            if (nations.get(nation2).getDefense() == 0){
                nations.get(nation1).substractArmy();
                nations.get(nation2).sumArmy();
                exist = true;
            }
            else if (nations.get(nation2).getDefense() > 0){
                nations.get(nation1).substractArmy();
                nations.get(nation2).substractDefense();
                exist = true;
            }
        }
        else {
            okas = false;
        }
    }
    
    public String[] conqueredNations(){
        okas = false;
        conquered = new String[nations.size()];
        for(int i = 0; i < nations.size(); i++){
            if (nations.get(i).isConquered()){
                conquered[i] = nations.get(i).getColor();
                okas = true;
            }
        }
        return conquered;
    }
    
    public int payments(){
        return totalCost;
    }
    
    public boolean conquer(){
        okas = false;
        quantConquered = 0;
        for(int i = 0; i < nations.size(); i++){
            if (nations.get(i).isConquered()){
                quantConquered += 1;
                okas = true;
            }
        }
        return quantConquered == nations.size();
    }
    
    public void makeVisible(){
        board.makeVisible();
        for(int i  = 0; i < nations.size(); i++){
            nations.get(i).makeVisible();
        }
        
        for(int i  = 0; i < routes.size(); i++){
            routes.get(i).makeVisible();
        }
        
        for(int i  = 0; i < armies.size(); i++){
            armies.get(i).makeVisible();
        }
        okas = true;
    }
    
    public void makeInvisible(){
        for(int i  = 0; i < nations.size(); i++){
            nations.get(i).makeInvisible();
        }
        
        for(int i  = 0; i < routes.size(); i++){
            routes.get(i).makeInvisible();
        }
        
        for(int i  = 0; i < armies.size(); i++){
            armies.get(i).makeInvisible();
        }
        okas = true;
        board.makeInvisible();
    }
    
    public void finish(){
        System.exit(0);
    }
    
    public boolean ok(){
        if (okas){
            JOptionPane.showMessageDialog(null, "La accion se realizo correctamente.");
        }
        else{
            JOptionPane.showMessageDialog(null, "La accion no se pudo realizar correctamente.");
        }
        return okas;
    }
}
