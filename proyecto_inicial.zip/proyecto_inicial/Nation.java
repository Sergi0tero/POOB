
/**
 * Write a description of class Nation here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nation
{
    private Rectangle land;
    private String color;
    private boolean conquered;
    private Triangle conquerTriangle;
    private int xPosition;
    private int yPosition;
    private boolean visible;
    private Digit digitArmies;
    private int armies;
    private int army;
    private Digit armyDigit;

    /**
     * Constructor for objects of class Nation
     */
    public Nation(String color, int x, int y, int armies){
        this.color = color;
        this.armies = armies;
        xPosition = x;
        yPosition = y;
        visible = false;
        land= new Rectangle();
        land.changeSize(50, 50);
        land.moveTo(x, y);
        land.changeColor(color);
        this.createArmy();
    }
    
    public int getDefense(){
        return armies;
    }
    
    public int getArmy(){
        return army;
    }
    
    public void sumArmy(){
        army += 1;
        armyDigit.next();
    }
    
    public void substractArmy(){
        army -= 1;
        armyDigit.prev();
    }
    
    public void sumDefense(){
        armies += 1;
        digitArmies.next();
    }
    
    public void substractDefense(){
        armies -= 1;
        digitArmies.prev();
        if (armies == 0){
            conquered = true;
            this.conquer();
            army = 0;
            armyDigit = new Digit(army);
            armyDigit.moveTo(xPosition + 20, yPosition);
            armyDigit.changeColor("white");
            armyDigit.makeVisible();
            digitArmies.makeInvisible();
        }
    }
    
    public boolean isConquered(){
        return conquered;
    }
    
    public void conquer(){
        conquerTriangle = new Triangle();
        conquerTriangle.moveTo(xPosition + 25, yPosition);
        conquerTriangle.changeSize(49, 50);
        conquerTriangle.changeColor("black");
        conquerTriangle.makeVisible();
        conquered = true;
    }
    
    public int getX(){
        return land.getX();
    }
    
    public int getY(){
        return land.getY();
    }
    
    public String getColor(){
        return color;
    }
    
    public boolean isVisible(){
        return visible;
    }
    
    public void armiesVisible(){
        digitArmies.makeVisible();
    }
    
    public void armyVisible(){
        armyDigit.makeVisible();
    }
    
    /**
     * 
     */
    public void makeVisible(){
        land.makeVisible();
        visible = true;
        if (armies == 0){
            armyDigit.makeVisible();
        }
        else {
            digitArmies.makeVisible();
        }
    }
    
    /**
     * 
     */
    public void makeInvisible()
    {
        if (armies == 0){
            armyDigit.makeInvisible();
            conquerTriangle.makeInvisible();
        }
        else {
            digitArmies.makeInvisible();
        }
        land.makeInvisible();
        visible = false;
    }
    
    private void createArmy(){
        if (armies > 0){
            digitArmies = new Digit(armies);
            digitArmies.moveTo(xPosition + 20, yPosition);
            conquered = false;
        }
        else{
            conquered = true;
            army = 0;
            armyDigit = new Digit(army);
            armyDigit.moveTo(xPosition + 20, yPosition);
            armyDigit.changeColor("white");
            armyDigit.makeVisible();
        }
    }
}
