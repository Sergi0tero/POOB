public class Evaluation {

	private int date;

	private int percentage;

	private Inscription inscription;

}
