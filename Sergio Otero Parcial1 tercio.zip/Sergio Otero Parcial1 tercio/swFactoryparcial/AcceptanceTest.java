public class AcceptanceTest {

    private String description;

    private int AcceptancePercentage;

    private HumanEvaluator humanEvaluator;
    
    /*
     * elimina un test de aceptacion
     */
    public boolean deleteATest(){
        return true;
    }
}
