public class Requirement {

    private String urlDetail;

    private int maxPoints;

    private Project project;

    private Project projectt;
    
    /*
     * elimina un requerimiento
     */
    public boolean deleteRequirements(){
        return true;
    }
}
