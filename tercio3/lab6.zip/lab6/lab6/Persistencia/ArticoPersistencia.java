package Persistencia;

import dominio.Artico;
import dominio.ArticoExcepcion;

import java.io.File;

public class ArticoPersistencia {

}
