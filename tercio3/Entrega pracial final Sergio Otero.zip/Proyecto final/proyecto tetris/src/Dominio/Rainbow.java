package Dominio;

public class Rainbow extends Figura {
    protected int estados = 1;
    protected int numType = 16;

    public Rainbow(int[][] tablero, boolean bolflag, int posy, char tipo ) {
        super('A', tipo);
        this.tablero = tablero;
        this.bolflag = bolflag;
        this.posy = posy;
        setTablero();
    }

    int[][] estado1 = new int[][]{
            {0,16,16,0},
            {16,0,0,16}
    };

    private void setTablero() {
        for(int i=0; i< 2; i++){
            for(int j=0; j< 4; j++){
                if(tablero[i][j+3] == 0) {
                    tablero[i][j + 3] = estado1[i][j];
                }
            }
        }
    }

    @Override
    protected int[][] getEstado() {
        return tablero;
    }

    @Override
    public int[][] abajo() {
        boolean bandera = true;
        for (int i = 19; i >= 0; i -= 1) {
            for (int j = 9; j >= 0; j -= 1) {
                if(tablero[i][j] == 16 && i < 19 && j>0){
                    if(tablero[i+1][j] == 6 || tablero[i+1][j-1] == 6 || tablero[i+1][j] == 7 || tablero[i+1][j-1] == 7 || tablero[i+1][j] == 8 || tablero[i+1][j-1] == 8 || tablero[i+1][j] == 9 || tablero[i+1][j-1] == 9) {
                        bufocapturado();
                    }
                }
                if (tablero[19][j] == 16 || bandera && j > 0 && tablero[i][j] == 16 && (tablero[i + 1][j] < 0 || tablero[i][j - 1] < 0 || tablero[i][j - 2] < 0|| tablero[i + 1][j - 3] < 0)) {
                    bandera = false;
                    llegoAbajo();
                } else if ( i > 0 && tablero[i][j] == 16 && tablero[i - 1][j - 1] == 16 && i < 19 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i + 1][j] = 16;
                    tablero[i - 1][j - 1] = 0;
                    tablero[i][j - 1] = 16;
                    tablero[i - 1][j - 2] = 0;
                    tablero[i][j - 2] = 16;
                    tablero[i][j - 3] = 0;
                    tablero[i + 1][j - 3] = 16;
                }
            }
        }
        return tablero;
    }

    @Override
    public int[][] nextState() {
        return tablero;
    }

    @Override
    public int[][] mueveDerecha() {
        boolean bandera = true;
        for (int i = 19; i >= 0; i -= 1) {
            for (int j = 9; j >= 0; j -= 1) {
                if(tablero[i][j] == 16  && i < 19 && j<9 && i > 0){
                    if(tablero[i][j+1] == 6 || tablero[i-1][j+1] == 6 || tablero[i][j+1] == 7 || tablero[i-1][j+1] == 7 || tablero[i][j+1] == 8 || tablero[i-1][j+1] == 8 || tablero[i][j+1] == 9 || tablero[i-1][j+1] == 9) {
                        bufocapturado();
                    }
                }
                if (j > 2 && j < 9 && i > 0 && tablero[i][j] == 16 && tablero[i - 1][j - 1] == 16 && tablero[i][j + 1] >= 0 && tablero[i - 1][j] >= 0 && tablero[i - 1][j - 1] >= 0 && tablero[i][j-2] >= 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i - 1][j-1] = 0;
                    tablero[i - 1][j - 2] = 0;
                    tablero[i][j-3] = 0;
                    tablero[i][j + 1] = 16;
                    tablero[i - 1][j] = 16;
                    tablero[i - 1][j - 1] = 16;
                    tablero[i][j-2] = 16;
                }
            }
        }
        return tablero;
    }

    @Override
    public boolean getflag() {
        return bolflag;
    }

    @Override
    public void setposy(int posy) {
        this.posy = posy;
    }

    @Override
    public int[][] mueveIzquierda() {
        boolean bandera = true;
        for (int i = 19; i >= 0; i -= 1) {
            for (int j = 9; j >= 0; j -= 1) {
                if(tablero[i][j] == 16  && i < 19 && j>1 && i > 0){
                    if(tablero[i][j-2] == 6 || tablero[i-1][j-2] == 6 || tablero[i][j-2] == 7 || tablero[i-1][j-2] == 7 || tablero[i][j-2] == 8 || tablero[i-1][j-2] == 8 || tablero[i][j-2] == 9 || tablero[i-1][j-2] == 9) {
                        bufocapturado();
                    }
                }
                if (j > 3 && i > 0 && tablero[i][j] == 16 && tablero[i - 1][j - 1] == 16 && tablero[i][j - 1] >= 0 && tablero[i - 1][j - 2] >= 0 && tablero[i - 1][j - 3] >= 0 && tablero[i][j - 4] >= 0 && bandera) {
                    bandera = false;
                    tablero[i][j] = 0;
                    tablero[i][j - 1] = 16;
                    tablero[i - 1][j - 1] = 0;
                    tablero[i - 1][j - 2] = 16;
                    tablero[i - 1][j - 3] = 16;
                    tablero[i][j - 3] = 0;
                    tablero[i][j - 4] = 16;
                }
            }
        }
        return tablero;
    }

    @Override
    public int[][] Winner() {
        return tablero;
    }

    @Override
    public int[][] Bomb(int i, int j) {
        return tablero;
    }

    @Override
    protected void llegoAbajo() {
        for (int i =19; i>=0; i-=1) {
            for (int j = 9; j>=0; j-=1) {
                if(tablero[i][j] == 16)tablero[i][j] = -16;
            }
        }
        bolflag = false;
    }
}
